package com.next.mq;

public interface QueueConstants {

    String COMMON_EXCHANGE = "common_exchange";

    String COMMON_QUEUE = "common_queue";

    String COMMON_ROUTING = "common_routing";

    String DELAY_EXCHANGE = "delay_exchange";

    String DELAY_QUEUE = "delay_queue";

    String DELAY_ROUTING = "delay_routing";

}
