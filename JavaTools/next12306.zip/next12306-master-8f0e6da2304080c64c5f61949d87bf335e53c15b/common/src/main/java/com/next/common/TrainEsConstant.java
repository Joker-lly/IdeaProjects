package com.next.common;

public interface TrainEsConstant {

    String INDEX = "index-station-number";

    String TYPE = "doc";

    String COLUMN_TRAIN_NUMBER = "trainNumber";
}
